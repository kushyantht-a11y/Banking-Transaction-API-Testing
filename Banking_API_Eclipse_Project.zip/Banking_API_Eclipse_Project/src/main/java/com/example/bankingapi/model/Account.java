package com.example.bankingapi.model;
import java.math.BigDecimal;
public class Account {
 private Long id; private String name; private BigDecimal balance;
 public Account(Long id, String name, BigDecimal balance) { this.id=id; this.name=name; this.balance=balance; }
 public Long getId(){return id;} public String getName(){return name;}
 public BigDecimal getBalance(){return balance;} public void setBalance(BigDecimal balance){this.balance=balance;}
}

package com.example.bankingapi.service;
import com.example.bankingapi.model.Account;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
@Service
public class BankService {
 private final ConcurrentHashMap<Long,Account> accounts=new ConcurrentHashMap<>();
 private final AtomicLong idGenerator=new AtomicLong(1001);
 public Account createAccount(String name) {
  if(name==null || name.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Account holder name is required");
  Long id=idGenerator.getAndIncrement(); Account a=new Account(id,name,BigDecimal.ZERO); accounts.put(id,a); return a;
 }
 public Account getAccount(Long id) {
  Account a=accounts.get(id); if(a==null) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Account not found"); return a;
 }
 public Account deposit(Long id,BigDecimal amount) {
  Account a=getAccount(id); validateAmount(amount); a.setBalance(a.getBalance().add(amount)); return a;
 }
 public Account withdraw(Long id,BigDecimal amount) {
  Account a=getAccount(id); validateAmount(amount);
  if(a.getBalance().compareTo(amount)<0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Insufficient balance");
  a.setBalance(a.getBalance().subtract(amount)); return a;
 }
 private void validateAmount(BigDecimal amount) {
  if(amount==null || amount.compareTo(BigDecimal.ZERO)<=0)
   throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Amount must be greater than zero");
 }
}

package com.example.bankingapi.controller;
import com.example.bankingapi.model.Account;
import com.example.bankingapi.model.TransactionRequest;
import com.example.bankingapi.service.BankService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
@RestController
@RequestMapping("/api/accounts")
@Validated
public class BankController {
 private final BankService service;
 public BankController(BankService service){this.service=service;}
 @PostMapping
 public Account createAccount(@Valid @RequestBody CreateAccountRequest request){return service.createAccount(request.name());}
 @PostMapping("/{id}/deposit")
 public Account deposit(@PathVariable Long id,@Valid @RequestBody TransactionRequest request){return service.deposit(id,request.getAmount());}
 @PostMapping("/{id}/withdraw")
 public Account withdraw(@PathVariable Long id,@Valid @RequestBody TransactionRequest request){return service.withdraw(id,request.getAmount());}
 @GetMapping("/{id}/balance")
 public BigDecimal balance(@PathVariable Long id){return service.getAccount(id).getBalance();}
 public record CreateAccountRequest(@NotBlank(message="Name is required") String name){}
}
